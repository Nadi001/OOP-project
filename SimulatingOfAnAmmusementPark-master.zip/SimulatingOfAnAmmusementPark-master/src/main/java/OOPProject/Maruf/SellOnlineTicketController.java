package com.example.demo2.Maruf;

public class SellOnlineTicketController
{
    @javafx.fxml.FXML
    public void initialize() {
    }}