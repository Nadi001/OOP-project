package com.example.demo2.Maruf;

public class SubmitFeedbackController
{
    @javafx.fxml.FXML
    public void initialize() {
    }}