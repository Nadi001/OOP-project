package com.example.demo2.Maruf;

public class VerifyTicketController
{
    @javafx.fxml.FXML
    public void initialize() {
    }}