package com.example.demo2.Maruf;

public class ViewParkMapController
{
    @javafx.fxml.FXML
    public void initialize() {
    }}