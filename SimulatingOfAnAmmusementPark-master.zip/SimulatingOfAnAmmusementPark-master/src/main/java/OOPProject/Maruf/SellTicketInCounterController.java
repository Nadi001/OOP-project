package com.example.demo2.Maruf;

public class SellTicketInCounterController
{
    @javafx.fxml.FXML
    public void initialize() {
    }}