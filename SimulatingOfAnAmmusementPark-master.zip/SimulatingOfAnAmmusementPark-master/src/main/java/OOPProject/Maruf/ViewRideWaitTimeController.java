package com.example.demo2.Maruf;

public class ViewRideWaitTimeController
{
    @javafx.fxml.FXML
    public void initialize() {
    }}