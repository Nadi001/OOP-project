package com.example.demo2.Maruf;

public class CancelTicketController
{
    @javafx.fxml.FXML
    public void initialize() {
    }}