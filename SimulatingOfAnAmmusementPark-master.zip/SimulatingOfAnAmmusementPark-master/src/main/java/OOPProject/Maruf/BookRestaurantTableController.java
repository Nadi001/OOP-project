package com.example.demo2.Maruf;

public class BookRestaurantTableController
{
    @javafx.fxml.FXML
    public void initialize() {
    }}