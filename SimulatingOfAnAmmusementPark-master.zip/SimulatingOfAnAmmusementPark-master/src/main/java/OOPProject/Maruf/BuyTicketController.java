package OOPProject.Maruf;

public class BuyTicketController
{
    @javafx.fxml.FXML
    public void initialize() {
    }}