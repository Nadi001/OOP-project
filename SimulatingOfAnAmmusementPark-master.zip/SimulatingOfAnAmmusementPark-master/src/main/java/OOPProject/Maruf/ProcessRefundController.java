package com.example.demo2.Maruf;

public class ProcessRefundController
{
    @javafx.fxml.FXML
    public void initialize() {
    }}