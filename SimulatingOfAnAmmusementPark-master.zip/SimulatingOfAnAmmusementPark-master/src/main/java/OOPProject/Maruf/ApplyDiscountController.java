package com.example.demo2.Maruf;

import javafx.event.ActionEvent;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class ApplyDiscountController
{
    @javafx.fxml.FXML
    private TextField discountTicketField;
    @javafx.fxml.FXML
    private Label discountDtatusLabel;
    @javafx.fxml.FXML
    private TextField discountPercentField;

    @javafx.fxml.FXML
    public void initialize() {
    }

    @javafx.fxml.FXML
    public void applyDiscountBtn(ActionEvent actionEvent) {
    }
}