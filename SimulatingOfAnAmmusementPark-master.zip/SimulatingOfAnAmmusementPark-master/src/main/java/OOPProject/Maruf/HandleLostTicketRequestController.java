package com.example.demo2.Maruf;

public class HandleLostTicketRequestController
{
    @javafx.fxml.FXML
    public void initialize() {
    }}