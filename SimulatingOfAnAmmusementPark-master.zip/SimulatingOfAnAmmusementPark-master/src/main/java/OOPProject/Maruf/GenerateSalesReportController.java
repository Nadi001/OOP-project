package com.example.demo2.Maruf;

public class GenerateSalesReportController
{
    @javafx.fxml.FXML
    public void initialize() {
    }}