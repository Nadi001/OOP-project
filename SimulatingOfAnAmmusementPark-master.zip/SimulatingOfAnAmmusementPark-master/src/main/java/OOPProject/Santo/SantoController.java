package OOPProject.Santo;

public class SantoController
{
    @javafx.fxml.FXML
    public void initialize() {
    }}