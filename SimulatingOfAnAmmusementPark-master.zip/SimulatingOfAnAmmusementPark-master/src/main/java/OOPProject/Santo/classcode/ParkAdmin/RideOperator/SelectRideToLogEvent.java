package OOPProject.Santo.classcode.ParkAdmin.RideOperator;

public class SelectRideToLogEvent {
}
