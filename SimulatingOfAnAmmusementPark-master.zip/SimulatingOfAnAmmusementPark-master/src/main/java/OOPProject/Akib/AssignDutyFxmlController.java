package OOPProject.Akib;

import javafx.event.ActionEvent;
import javafx.scene.control.*;

public class AssignDutyFxmlController {
    @javafx.fxml.FXML
    private TableColumn assignedZoneTableColumn;
    @javafx.fxml.FXML
    private TextField dutyZoneTextField;
    @javafx.fxml.FXML
    private TableColumn officerNameTableColumn;
    @javafx.fxml.FXML
    private Label selectedOfficerLabel;
    @javafx.fxml.FXML
    private Label messageLabel;
    @javafx.fxml.FXML
    private TableView securityTableView;

    @javafx.fxml.FXML
    public void assignButtonOnAction(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void notifyNotificationButtonOnAction(ActionEvent actionEvent) {
    }
}
