package OOPProject.Akib;

import javafx.event.ActionEvent;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class technicalIssueFxmlController {
    @javafx.fxml.FXML
    private TextField areaInvolvedTextField;
    @javafx.fxml.FXML
    private TextArea descriptionFieldTextArea;
    @javafx.fxml.FXML
    private ComboBox priorityLevelComboBox;
    @javafx.fxml.FXML
    private Label messageLabel;

    @javafx.fxml.FXML
    public void assignButtonOnAction(ActionEvent actionEvent) {
    }
}
