package OOPProject.Akib;

import javafx.event.ActionEvent;
import javafx.scene.control.*;
import OOPProject.Akib.completeRepair;

public class CompleteRepairController {
    @javafx.fxml.FXML
    private TextField equipmentNameTextField;
    @javafx.fxml.FXML
    private DatePicker repairDateDatePicker;
    @javafx.fxml.FXML
    private TextArea descriptionTextArea;
    @javafx.fxml.FXML
    private Label messageLabel;

    @javafx.fxml.FXML
    public void submitButtonOnAction(ActionEvent actionEvent) {
    }
}
