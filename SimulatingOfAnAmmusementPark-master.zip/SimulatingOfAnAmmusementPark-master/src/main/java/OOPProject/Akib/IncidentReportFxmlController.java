package OOPProject.Akib;

import javafx.event.ActionEvent;
import javafx.scene.control.*;

public class IncidentReportFxmlController {
    @javafx.fxml.FXML
    private ComboBox selectIncidentComboBox;
    @javafx.fxml.FXML
    private TextArea descriptionTextArea;
    @javafx.fxml.FXML
    private TextField timeTextField;
    @javafx.fxml.FXML
    private TextField locationTextField;
    @javafx.fxml.FXML
    private Label messageLabel;

    @javafx.fxml.FXML
    public void submitButtonOnAction(ActionEvent actionEvent) {
    }
}
