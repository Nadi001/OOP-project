package OOPProject.Akib;

import javafx.event.ActionEvent;
import javafx.scene.control.*;

public class MaintenanceHistoryController
{
    @javafx.fxml.FXML
    private DatePicker endDateDatePicker;
    @javafx.fxml.FXML
    private TableColumn taskTypeTableColumn;
    @javafx.fxml.FXML
    private TableColumn staffTableColumn;
    @javafx.fxml.FXML
    private ComboBox equipmentComboBox;
    @javafx.fxml.FXML
    private TableColumn dateTableColumn;
    @javafx.fxml.FXML
    private TableColumn outcomeTableColumn;
    @javafx.fxml.FXML
    private ComboBox taskTypeComboBox;
    @javafx.fxml.FXML
    private TableView historyTableView;
    @javafx.fxml.FXML
    private DatePicker startDateDatePicker;
    @javafx.fxml.FXML
    private Label messageLabel;
    @javafx.fxml.FXML
    private TableColumn equipmentTableColumn;

    @javafx.fxml.FXML
    public void initialize() {
    }

    @javafx.fxml.FXML
    public void genarateReportButtonOnAction(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void searchButtonOnAction(ActionEvent actionEvent) {
    }
}