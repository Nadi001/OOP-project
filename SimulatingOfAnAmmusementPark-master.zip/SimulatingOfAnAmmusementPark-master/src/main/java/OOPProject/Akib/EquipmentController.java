package OOPProject.Akib;

import javafx.event.ActionEvent;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

public class EquipmentController
{
    @javafx.fxml.FXML
    private ComboBox affectedAreaComboBox;
    @javafx.fxml.FXML
    private TextField issueDescriptionTextField;
    @javafx.fxml.FXML
    private ComboBox priorityLevelComboBox;

    @javafx.fxml.FXML
    public void initialize() {
        
    }

    @javafx.fxml.FXML
    public void submitButtonOnAction(ActionEvent actionEvent) {
    }
}