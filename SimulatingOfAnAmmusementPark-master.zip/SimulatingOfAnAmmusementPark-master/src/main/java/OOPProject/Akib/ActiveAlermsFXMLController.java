package OOPProject.Akib;

import javafx.event.ActionEvent;
import javafx.scene.control.*;

public class ActiveAlermsFXMLController {
    @javafx.fxml.FXML
    private TableColumn triggerTimeTableColumn;
    @javafx.fxml.FXML
    private TextField patrolDetailsTextField;
    @javafx.fxml.FXML
    private TableView activeAlermsTableView;
    @javafx.fxml.FXML
    private TableView patrolHistoryTableView;
    @javafx.fxml.FXML
    private TableColumn typeTableColumn;
    @javafx.fxml.FXML
    private TableColumn endTimeTableColumn;
    @javafx.fxml.FXML
    private TableColumn locationTablecolumn;
    @javafx.fxml.FXML
    private Label messageLabel;
    @javafx.fxml.FXML
    private TableColumn startTimeTableColumn;
    @javafx.fxml.FXML
    private TableColumn zoneTableColumn;

    @javafx.fxml.FXML
    public void endPatrolButtonOnAction(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void startPatrolButtonOnAction(ActionEvent actionEvent) {
    }
}
