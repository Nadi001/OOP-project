package OOPProject.Akib;

import javafx.event.ActionEvent;
import javafx.scene.control.*;

public class SparePartsOrderController
{
    @javafx.fxml.FXML
    private TextField partNameTextField;
    @javafx.fxml.FXML
    private Label messageLabel;
    @javafx.fxml.FXML
    private TextField quantityTextField;
    @javafx.fxml.FXML
    private ComboBox supplierComboBox;

    @javafx.fxml.FXML
    public void initialize() {
    }

    @javafx.fxml.FXML
    public void submitButtonOnAction(ActionEvent actionEvent) {
    }
}